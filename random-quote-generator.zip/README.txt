A Pen created at CodePen.io. You can find this one at http://codepen.io/billywaite/pen/pgBWgL.

 Learning to use jQuery and Ajax